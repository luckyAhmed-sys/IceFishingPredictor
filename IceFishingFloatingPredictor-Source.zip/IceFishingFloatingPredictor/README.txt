ICE FISHING FLOATING PREDICTOR — SOURCE PROTOTYPE

What this is:
- A basic Android project that displays a movable floating statistics panel over another app.
- The panel lets you record visible result categories and calculates historical frequency.

What it does NOT do:
- It does not read the game's screen automatically.
- It does not identify wheel icons or announcements.
- It cannot predict the next casino outcome or guarantee a win.
- It is source code, not an installable APK.

Build requirement:
- Android Studio / Android SDK and Gradle are required to compile an APK.
- Open this folder as a project in Android Studio, then Build > Build APK(s).
- On the phone, install only after reviewing Android's overlay permission prompt.

Phone-only note:
Without a computer or a cloud Android build service, this source ZIP cannot be turned into an APK directly on this phone. The earlier HTML tracker remains usable in Chrome for manual result entry.
