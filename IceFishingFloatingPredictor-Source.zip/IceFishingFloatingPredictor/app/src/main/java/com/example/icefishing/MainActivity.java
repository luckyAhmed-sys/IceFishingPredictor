package com.example.icefishing;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28,32,28,24);
        layout.setBackgroundColor(0xFF102B3A);
        TextView title = new TextView(this);
        title.setText("🎣 Ice Fishing Predictor");
        title.setTextColor(0xFFFFFFFF); title.setTextSize(24);
        layout.addView(title);
        TextView info = new TextView(this);
        info.setText("\nFloating panel prototype\n\nThis app displays a movable statistics panel over other apps. It does not know or predict the casino's next random outcome. Add verified results in the panel to track historical frequency.");
        info.setTextColor(0xFFD8E8EF); info.setTextSize(16);
        layout.addView(info);
        Button permission = new Button(this); permission.setText("1. Allow display over other apps");
        layout.addView(permission);
        Button start = new Button(this); start.setText("2. Start floating panel");
        layout.addView(start);
        TextView status = new TextView(this); status.setTextColor(0xFFB9D1DC); layout.addView(status);
        permission.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
                startActivity(i);
            } else status.setText("Overlay permission is already enabled.");
        });
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                status.setText("Please allow display-over-other-apps permission first.");
                return;
            }
            startService(new Intent(this, FloatingService.class));
            status.setText("Floating panel started. Return to the game; tap ✕ to close it.");
        });
        setContentView(layout);
    }
}
