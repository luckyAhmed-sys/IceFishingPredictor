package com.example.icefishing;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.*;
import android.widget.*;
import java.util.*;

public class FloatingService extends Service {
    private WindowManager wm;
    private View panel;
    private final String[] labels = {"Lil' Blues","Big Oranges","Huge Reds","All Bonuses"};
    private final int[] counts = new int[4];

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14,10,14,12);
        box.setBackgroundColor(0xEE12394A);
        TextView head = new TextView(this);
        head.setText("🎣 ICE FISHING  ·  STATS");
        head.setTextColor(0xFFFFFFFF); head.setTextSize(14);
        box.addView(head);
        TextView disclaimer = new TextView(this);
        disclaimer.setText("Historical tracker — not a next-spin prediction");
        disclaimer.setTextColor(0xFFBBD4DE); disclaimer.setTextSize(10);
        box.addView(disclaimer);
        TextView summary = new TextView(this);
        summary.setTextColor(0xFFFFFFFF); summary.setTextSize(12);
        box.addView(summary);
        for (int j=0;j<labels.length;j++) {
            final int idx=j;
            Button add = new Button(this);
            add.setText("+ " + labels[j]);
            add.setTextSize(10);
            box.addView(add);
            add.setOnClickListener(v -> { counts[idx]++; update(summary); });
        }
        Button close = new Button(this); close.setText("✕ Close panel"); box.addView(close);
        close.setOnClickListener(v -> stopSelf());
        update(summary);
        panel=box;
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            260, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.RIGHT; p.x=16; p.y=150;
        box.setOnTouchListener(new View.OnTouchListener(){
            int sx,sy; float tx,ty;
            public boolean onTouch(View v, android.view.MotionEvent e) {
                if(e.getAction()==MotionEvent.ACTION_DOWN){sx=p.x;sy=p.y;tx=e.getRawX();ty=e.getRawY();return false;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){p.x=sx+(int)(tx-e.getRawX());p.y=sy+(int)(e.getRawY()-ty);wm.updateViewLayout(panel,p);return true;}
                return false;
            }
        });
        wm.addView(panel,p);
    }
    private void update(TextView t) {
        int total=0; for(int c:counts) total+=c;
        StringBuilder s=new StringBuilder("Rounds entered: "+total+"\n");
        for(int i=0;i<labels.length;i++){
            int pct=total==0?0:Math.round(100f*counts[i]/total);
            s.append(labels[i]).append(": ").append(counts[i]).append(" (").append(pct).append("%)\n");
        }
        s.append("\nPast frequency only; outcomes may be random.");
        t.setText(s.toString());
    }
    @Override public void onDestroy(){ if(panel!=null && wm!=null) wm.removeView(panel); super.onDestroy(); }
    @Override public IBinder onBind(Intent i){ return null; }
}
